import UIKit

var name = "Walker"
var numSum = 22+13
var numDiff = 10-3
var numProduct = 5*10
var numDiv = 16/4
var numRem = 18%5

print(name)
print(numSum)
print(numDiff)
print(numProduct)
print(numDiv)
print(numRem)
