struct Person {
    var name: String;
    var age: Int;
    var location: String;
    
    func whoAmI() {
        print("Hi, I'm \(name)! I am \(age) and live in \(location).")
    }
}

let a_person = Person(name: "Walker", age: 26, location: "New Orleans")
let b_person = Person(name: "Madeleine", age: 21, location: "New Orleans")

print(a_person.location);
print(b_person.age);

a_person.whoAmI()
b_person.whoAmI()


//Making a function called water meter
struct WaterMeter {
    var litresUsed: Int = 0;
    var customer: Person = Person(name: "Walker", age: 26, location: "New Orleans");
    
}

let theMeter = WaterMeter()

print(theMeter.litresUsed)
print(theMeter.customer.age)
