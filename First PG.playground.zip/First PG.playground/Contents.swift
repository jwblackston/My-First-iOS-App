import UIKit

print("Hello world")

var greeting = "Hello Swift Developers"
print(greeting)

greeting = "Glad you are here"
print(greeting)

let mothersName = "Gretchen"
print(mothersName)


